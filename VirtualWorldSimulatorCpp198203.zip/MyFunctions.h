#pragma once
void Gotoxy(short x, short y);
void SetTextColour(int c);